import BallCanvas from "./Ball";
import ComputersCanvas from "./Computers";
import StarsCanvas from "./Stars";
import LottieEarth from "./LottieEarth"; // new

export { LottieEarth, BallCanvas, ComputersCanvas, StarsCanvas };
